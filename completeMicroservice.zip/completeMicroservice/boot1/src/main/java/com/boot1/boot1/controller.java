package com.boot1.boot1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
public class controller {
	
	@Autowired
	private FeignClientProxy feignClientProxy;
	
	@RequestMapping(value = "/")
	   public String hello() {
	      return "Hello World1";
	   }
	
	/*@RequestMapping(value="/students",method=RequestMethod.GET)
	public ResponseEntity<?> students(){

		HttpStatus httpStatus = null;
		Student st1=new Student();
		try {
			String uri="http://localhost:8090/students";
			 RestTemplate restTemplate = new RestTemplate();
		     st1 = restTemplate.getForObject(uri,Student.class);
		
				httpStatus=HttpStatus.OK;
			}
		catch(Exception ex) {
			httpStatus=HttpStatus.EXPECTATION_FAILED;
			return new ResponseEntity<>(httpStatus);

		}
		return new ResponseEntity<Student>(st1,httpStatus);
	}*/
	
	@RequestMapping(value="/students",method=RequestMethod.GET)
	public ResponseEntity<?> students(){

		HttpStatus httpStatus = null;
		Student st1=new Student();
		try {
			String uri="http://localhost:8090/students";
			// RestTemplate restTemplate = new RestTemplate();
		     //st1 = restTemplate.getForObject(uri,Student.class);
		st1=feignClientProxy.students();
				httpStatus=HttpStatus.OK;
			}
		catch(Exception ex) {
			httpStatus=HttpStatus.EXPECTATION_FAILED;
			return new ResponseEntity<>(httpStatus);

		}
		return new ResponseEntity<Student>(st1,httpStatus);
	}
}
