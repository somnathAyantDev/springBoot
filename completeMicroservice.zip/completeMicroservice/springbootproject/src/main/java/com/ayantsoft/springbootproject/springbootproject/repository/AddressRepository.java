package com.ayantsoft.springbootproject.springbootproject.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ayantsoft.springbootproject.springbootproject.model.Address;


public interface AddressRepository extends JpaRepository<Address,Integer>,Serializable{

	
}
