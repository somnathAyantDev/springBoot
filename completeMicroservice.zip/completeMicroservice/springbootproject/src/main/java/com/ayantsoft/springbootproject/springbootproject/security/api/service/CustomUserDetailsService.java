package com.ayantsoft.springbootproject.springbootproject.security.api.service;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ayantsoft.springbootproject.springbootproject.model.User;
import com.ayantsoft.springbootproject.springbootproject.repository.UserRepository;


@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	/*@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println(username);
		User user=userRepository.findByUsername(username);
		//User user=usrObj1.get();
	
		//User user = repository.findByUsername(username);
		CustomUserDetails userDetails = null;
		if (user != null) {
			System.out.println(user.getUsername());
			userDetails = new CustomUserDetails();
			userDetails.setUser(user);
		} else {
			throw new UsernameNotFoundException("User not exist with name : " + username);
		}
		return userDetails;

	}*/
	
	 @Override
	    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
	        User user = userRepository.findByUsername(userName);
	        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
	        		getAuthorities(user));
	        
	    }

	    private static Collection<? extends GrantedAuthority> getAuthorities(User user) {
	        String[] userRoles = user.getRoles().stream().map((role) -> role.getUser_role()).toArray(String[]::new);
	        Collection<GrantedAuthority> authorities = AuthorityUtils.createAuthorityList(userRoles);
	        return authorities;
	    }

}
