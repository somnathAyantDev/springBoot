package com.ayantsoft.springbootproject.springbootproject.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ayantsoft.springbootproject.springbootproject.model.Student;
import com.ayantsoft.springbootproject.springbootproject.model.User;


public interface UserRepository extends JpaRepository<User, Long>,Serializable{
			
	User findByUsername(String username);
	
	@Query("SELECT st.year FROM Student st where st.id<=:id")
	public Iterable<Student>getStudentsLessThanOrEqualParam(@Param("id") Long id);

}
